//
//  AppDelegate.h
//  ProjectBase
//
//  Created by sdebank on 2024/1/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property(nonatomic,strong) UIWindow* window;

@property (strong, nonatomic) MainTabBarController *mainTabBar;
@end

