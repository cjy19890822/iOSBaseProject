//
//  AppDelegate+PushService.h
//  MiAiApp
//
//  Created by 徐阳 on 2017/5/25.
//  Copyright © 2017年 徐阳. All rights reserved.
//

#import "AppDelegate.h"

/**
 推送相关在这里处理
 */
@interface AppDelegate (PushService)

@end
