//
//  ViewController.m
//  ProjectBase
//
//  Created by sdebank on 2024/1/24.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    self.view.backgroundColor = [UIColor yellowColor];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
